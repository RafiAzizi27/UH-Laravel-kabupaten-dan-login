<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelSatpam extends Model
{
    protected $table = "model_satpam";
}
