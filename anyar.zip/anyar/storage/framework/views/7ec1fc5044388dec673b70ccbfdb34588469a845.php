<?php $__env->startSection('content'); ?>
    <section class="main-section">
        <div class="content">
            <h1>Tambah Pembelian</h1>
            <hr>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('pembelian.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="kd_barang">Nama Barang:</label>
                <input type="text" class="form-control" id="usr" name="kd_barang">
            </div>
            <div class="form-group">
                <label for="jumlah">Jumlah:</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah">
            </div>
            <div class="form-group">
                <label for="total_harga">total Harga:</label>
                <input type="text" class="form-control" id="total_harga" name="total_harga">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\anyar\resources\views/pembelian_create.blade.php ENDPATH**/ ?>